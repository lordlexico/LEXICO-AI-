function signUp() {
  const email = document.getElementById("signup-email").value;
  if (email) {
    alert(`Signed up successfully with email: ${email}`);
  } else {
    alert("Please enter your email to sign up.");
  }
}

async function sendMessage() {
  const input = document.getElementById("user-input").value;
  const chatContainer = document.getElementById("chat-container");

  if (!input) {
    alert("Please type a message.");
    return;
  }

  // Add the user's message to the chat
  chatContainer.innerHTML += `<div><strong>You:</strong> ${input}</div>`;

  try {
    // Send the user's message to the backend
    const response = await fetch("http://localhost:5000/api/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ message: input }),
    });

    const data = await response.json();
    const aiResponse = data.message || "Sorry, something went wrong.";

    // Add the AI's response to the chat
    chatContainer.innerHTML += `<div><strong>LEXICO AI:</strong> ${aiResponse}</div>`;
  } catch (error) {
    console.error("Error:", error);
    chatContainer.innerHTML += `<div><strong>LEXICO AI:</strong> Sorry, something went wrong.</div>`;
  }

  // Clear the input field
  document.getElementById("user-input").value = "";
}